/*
 * Descripción: Primer uso de variables
 * Autor: Raúl Beltrán
 * Fecha: 23/09/2025
 */

package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		int num1 = 1, num2 = 2; // Declaraciones e Inicializaciones
		
		double val1, val2; // Declaración
		
		System.out.println("El primer número es: " + num1 + " El segundo número es: " + num2);
		
		val1 = 1;// Inicialización
		val2 = 2; // Inicialización
		
		System.out.println("El primer valor es: " + val1 + " El segundo valor es: " + val2);
		
		String miNombre = "Raúl"; // Declaración e Inicialización
		String misApellidos = "Beltrán Gracia"; // Declaración e Inicialización
		
		System.out.println("Mi nombre es: " + miNombre + " y mis apellidos: " + misApellidos);
	}

}
