/*
*  Descripción: Programa que muestra números del 1 al 25 guardados en array bidimensional
 * Autor: Raúl Beltrán
 * Fecha: 31/10/2025
 */
package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {

	final int TOTAL_NUM = 5;
	
	int [][] bidimensional;
	bidimensional = new int [TOTAL_NUM][TOTAL_NUM];

	int suma = 0;
	
		for (int y = 0; y < 5; y++) {	
			for (int x = 0; x < 5; x++) {
				suma = suma + 1;
				bidimensional[y][x] = suma;
			}
		}
		
		for (int y = 0; y < 5; y++) {	
			for (int x = 0; x < 5; x++) {
				System.out.print(bidimensional[y][x] + "\t ");
			}
			System.out.println();
		}
	
	}

}
