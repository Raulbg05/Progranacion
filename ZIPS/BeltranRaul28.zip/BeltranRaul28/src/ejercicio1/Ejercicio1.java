/*
 * Descripción: Mostrar números del 1 al 100 usando while
 * Autor: Raúl Beltrán
 * Fecha: 14/10/2025
 */
package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		int numero = 0;
		
		while (numero < 100) {
			numero++;
			System.out.println(numero);
		}

	}

}
