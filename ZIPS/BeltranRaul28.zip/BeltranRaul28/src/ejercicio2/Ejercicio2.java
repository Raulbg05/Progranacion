/*
 * Descripción: Mostrar números del 1 al 100 usando do-while
 * Autor: Raúl Beltrán
 * Fecha: 14/10/2025
 */
package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {
		int numero = 0;
		
		do {
			numero++;
			System.out.println(numero);
		}
		while (numero < 100);
	}

}
