/*
 * Descripción: Uso de variables
 * Autor: Raúl Beltrán
 * Fecha: 26/09/2025
 */
package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
	
	int num1, num2; 		
	num1 = 1;				
	num2 = 1;				
	
	char char1, char2; 		
	char1 = 'A';			
	char2 = 'A';			
	
	String Cargo, Nombre;		
	Cargo = "estudiante";	
	Nombre = " Beltrán";	
	
	System.out.println("El valor de el primer número es: " + num1 + "\nEl valor de el segundo número es: " + num2);
	System.out.println("Bienvenido, " + Cargo + Nombre);

	}

}
